import { useEffect } from "react";

const Shop = () => {
  useEffect(() => {}, []);
  const getProducts = () => {};

  return (
    <>
      <h2>Shop</h2>
    </>
  );
};
export default Shop;
